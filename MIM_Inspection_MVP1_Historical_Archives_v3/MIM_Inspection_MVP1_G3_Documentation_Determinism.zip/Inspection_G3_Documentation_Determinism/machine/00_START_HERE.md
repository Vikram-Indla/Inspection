# G3 Documentation Determinism - Start Here

## Gate result
**PASS**

G3 establishes canonical screen, route, field, reference-data, role, state, atomic-scope, decision and failure contracts for MVP1.

## Binding rules
1. The 478 source requirements remain mandatory.
2. An explicitly Phase 2 AI action does not defer its parent MVP1 requirement.
3. Fable may not invent business policy values recorded as open decisions.
4. Fable may not merge, omit or add canonical screens without change control.
5. Runtime permissions must enforce the RBAC matrix.
6. Runtime state changes must use canonical transitions and guards.
7. Failure paths must leave an unambiguous recoverable or terminal state.
8. G3 PASS does not authorize broad implementation. G4-G8 remain required.

## Read order
1. `G3_GATE_REPORT.md`
2. `screen_route_catalogue.csv`
3. `field_dictionary.csv`
4. `reference_data.csv`
5. `rbac_matrix.csv`
6. `state_transitions.csv`
7. `atomic_scope.csv`
8. `decision_register.csv`
9. `error_catalogue.csv`
