# Start Here — MVP1 Product Contract

This directory will become the authoritative machine-readable memory for Claude/Fable and the human-readable knowledge base for Obsidian.

## Required session read order

1. `MANIFEST.json`
2. `GATE_STATUS.md`
3. `CURRENT_STATE.md`
4. `OPEN_DECISIONS.yaml`
5. `execution/CURRENT_SLICE.yaml`
6. Only the process, channel, engine, design, API, and acceptance files referenced by the current slice

## Enforcement principle

Chat history is not a source of truth. The repository contract is the source of truth.
