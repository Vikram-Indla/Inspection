# G2 - Canonical End-to-End Process and Scope Freeze

**Gate decision: PASS**

This package is the single process authority for MVP1. Every BRD section, screen, API, Figma frame, Fable task, acceptance scenario and test must map to the process IDs defined here.

## Read order
1. Human atlas PDF and master PNG.
2. `master_process.md`.
3. `process_catalog.yaml`.
4. `alternate_paths.yaml`.
5. `scope_boundary.yaml`.
6. `traceability_matrix.csv`.
7. `G2_GATE_REPORT.md`.

## Hard rules
- Do not rename or reorder process IDs without approved change control.
- Do not invent values listed in `open_decisions.yaml`.
- Do not move MVP2 capabilities into MVP1.
- Do not start broad implementation until G3-G8 pass.
